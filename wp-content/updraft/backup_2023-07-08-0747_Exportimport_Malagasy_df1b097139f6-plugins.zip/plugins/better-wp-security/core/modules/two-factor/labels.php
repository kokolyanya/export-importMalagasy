<?php

return [
	'title' => __( 'Two-Factor', 'better-wp-security' ),
];
