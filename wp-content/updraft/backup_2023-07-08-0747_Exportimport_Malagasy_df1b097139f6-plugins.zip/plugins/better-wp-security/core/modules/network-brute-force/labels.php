<?php

return [
	'title' => __( 'Network Brute Force', 'better-wp-security' ),
];
