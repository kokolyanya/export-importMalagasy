<?php

return [
	'title' => __( 'SSL', 'better-wp-security' ),
];
